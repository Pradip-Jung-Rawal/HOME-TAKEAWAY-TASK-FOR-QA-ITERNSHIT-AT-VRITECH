from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
import traceback
import time


def test_signup_flow():
    driver = None

    try:
        driver = webdriver.Chrome()
        driver.maximize_window()
        wait = WebDriverWait(driver, 30)

        driver.get("https://authorized-partner.vercel.app/register?step=setup")

        # ================= STEP 1 =================

        first_name = wait.until(
            EC.visibility_of_element_located(
                (By.XPATH, "//label[contains(text(),'First')]/following::input[1]")
            )
        )

        last_name = wait.until(
            EC.visibility_of_element_located(
                (By.XPATH, "//label[contains(text(),'Last')]/following::input[1]")
            )
        )

        email = wait.until(
            EC.visibility_of_element_located((By.XPATH, "//input[@type='email']"))
        )

        phone = wait.until(
            EC.visibility_of_element_located(
                (By.XPATH, "//label[contains(text(),'Phone')]/following::input[1]")
            )
        )

        password_fields = wait.until(
            EC.presence_of_all_elements_located((By.XPATH, "//input[@type='password']"))
        )

        first_name.send_keys("Pradip")
        last_name.send_keys("Rawal")
        email.send_keys("pradipqa555@test.com")
        phone.send_keys("9769836999")

        password_fields[0].send_keys("Pass@12345")
        password_fields[1].send_keys("Pass@12345")

        next_button = wait.until(
            EC.element_to_be_clickable((By.XPATH, "//button[contains(.,'Next')]"))
        )
        driver.execute_script("arguments[0].click();", next_button)

        # ================= OTP STEP =================

        print("\nWaiting for OTP field...")

        otp_input = wait.until(
            EC.visibility_of_element_located(
                (By.XPATH, "//input[@maxlength='6']")
            )
        )

        print("⚠ Enter OTP manually in browser.")

        # Wait until 6 digits entered
        wait.until(lambda d: len(otp_input.get_attribute("value")) == 6)

        verify_button = wait.until(
            EC.element_to_be_clickable((By.XPATH, "//button[contains(.,'Verify')]"))
        )

        driver.execute_script("arguments[0].click();", verify_button)

        print("Verify clicked")

        # Wait for redirect to Step 2
        wait.until(EC.url_contains("step=details"))
        print("Moved to Agency Details")

    finally:
        time.sleep(5)
        if driver:
            driver.quit()


if __name__ == "__main__":
    test_signup_flow()